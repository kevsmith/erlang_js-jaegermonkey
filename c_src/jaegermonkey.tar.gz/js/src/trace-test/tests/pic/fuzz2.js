for each(let x in [0, {}, 0, {}]) {
  x.valueOf
}