(function () {
    for (var q = 0; q < 6; ++q) {
        x: (function () {
            var m = (function () {})()
        })([0, , 0, 0, 0, , 0, 0, 0, , 0, 0, 0, , 0, 0, 0, 0, 0, 0, Number(1)])
    }
})()

/* Don't assert. */

