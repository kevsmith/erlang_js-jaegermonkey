// |trace-test| error: ReferenceError
x ? o : [] && x

