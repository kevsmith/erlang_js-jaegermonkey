(function() {
  for (e in ((function() {
    yield
  })())) return
})()
/* Don't assert. */
