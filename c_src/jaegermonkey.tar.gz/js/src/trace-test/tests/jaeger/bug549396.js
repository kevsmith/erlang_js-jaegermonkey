x = __defineSetter__("x", function(z) function() { z })
