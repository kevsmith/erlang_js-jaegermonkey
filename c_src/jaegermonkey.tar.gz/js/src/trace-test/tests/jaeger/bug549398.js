(function () {
    eval("\
      for(var z = 0 ; z < 2 ; ++z) {\
        this\
      }\
      ", (<x/>))
})()

/* Don't crash. */

